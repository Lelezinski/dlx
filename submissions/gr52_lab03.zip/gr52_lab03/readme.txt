CAP3 LABORATORY

NOTES
- An additional readme is provided inside 'ex1.3/sim' for further explainations on the inner 
  workings of the windowed register file.
- Every syn folder has its corresponding synthesis script. For exercises 1.2 and 1.4 its name is 
  'syn.tcl'. For exercise 1.6 it's 'syn.txt'.